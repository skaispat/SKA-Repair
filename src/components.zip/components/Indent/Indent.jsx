import React, { useEffect, useState } from "react";
import { Plus, Search, Filter } from "lucide-react";
import Button from "../ui/Button";
import Modal from "../ui/Modal";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "../ui/Table";
import IndentForm from "./IndentForm";
import { mockRepairTasks } from "../../data/mockData";
import { useAuth } from "../../context/AuthContext";

const Indent = () => {
  const { user } = useAuth();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [loadingTasks, setLoadingTasks] = useState(false);

  // console.log("tasks", tasks);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredTasks = tasks
    .filter(
      (task) => user?.role === "admin" || task.nameOfIndenter === user?.name
    )
    .filter(
      (task) =>
        task.machineName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.taskNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.serialNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.doerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.machinePartName.toLowerCase().includes(searchTerm.toLowerCase())
    );

  const SCRIPT_URL =
    "https://script.google.com/macros/s/AKfycbzWDU77ND7kYIIf__m_v3hlFv74-lF68mgSMjb0OadKnNU4XJFr74zAqnDQG0FARtjd/exec";
  const SHEET_Id = "1lE5TdGcbmwVcVqbx-jftPIdmoGgg1DApNn4t9jZvGN8";
  const FOLDER_ID = "1IUX8rnhuodWWPQ2PPAFurz-S1Xoz-9h5";

  const fetchAllTasks = async () => {
    // console.log("selectedTaskType", selectedTaskType);
    try {
      setLoadingTasks(true);
      const SHEET_NAME_TASK = "Repair System";

      const res = await fetch(
        `${SCRIPT_URL}?sheetId=${SHEET_Id}&&sheet=${SHEET_NAME_TASK}`
      );
      const result = await res.json();

      const allRows = result?.table?.rows || [];

      // Skip first 5 rows (index 0 to 4)
      const taskRows = allRows.slice(5);

      const formattedTasks = taskRows.map((row) => {
        const cells = row.c;

        return {
          timestamp: cells[0]?.v || "",
          taskNo: cells[1]?.v || "",
          serialNo: cells[2]?.v || "",
          machineName: cells[3]?.v || "",
          machinePartName: cells[4]?.v || "",
          givenBy: cells[5]?.v || "",
          doerName: cells[6]?.v || "",
          problem: cells[7]?.v || "",
          enableReminder: cells[8]?.v || "",
          requireAttachment: cells[9]?.v || "",
          taskStartDate: cells[10]?.v || "",
          taskEndDate: cells[11]?.v || "",
          priority: cells[12]?.v || "",
          department: cells[13]?.v || "",
          location: cells[14]?.v || "",
          // Add more fields as needed
        };
      });

      // console.log("Formatted Tasks:", formattedTasks);
      setTasks(formattedTasks);
      // setTaskList(formattedTasks);
    } catch (err) {
      console.error("Error fetching tasks:", err);
    } finally {
      setLoadingTasks(false);
    }
  };

  useEffect(() => {
    fetchAllTasks();
  }, []);

  const getPriorityColor = (priority) => {
    switch (priority) {
      case "Critical":
        return "bg-red-100 text-red-800";
      case "High":
        return "bg-orange-100 text-orange-800";
      case "Medium":
        return "bg-yellow-100 text-yellow-800";
      case "Low":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const handleAddIndent = (data) => {
    //   const newTask = {
    //     id: String(tasks.length + 1),
    //     ...data
    //   };
    //   setTasks(prev => [...prev, newTask]);
    //   setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Indent Management</h1>
        {/* <Button onClick={() => setIsModalOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Indent
        </Button> */}
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center space-x-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search by machine name or task number..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <Button variant="secondary" size="sm">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
        </div>

        {/* <Table>
          <TableHeader>
            <TableHead>Repair Task Number</TableHead>
            <TableHead>Machine Name</TableHead>
            <TableHead>Serial No</TableHead>
            <TableHead>Doer</TableHead>
            <TableHead>Department</TableHead>
            <TableHead>Machine Part Name</TableHead>
            <TableHead>Priority</TableHead>
            <TableHead>Start Date</TableHead>
            <TableHead>End Date</TableHead>
            <TableHead>Status</TableHead>
          </TableHeader>
          <TableBody>
            {filteredTasks.map((task) => (
              <TableRow key={task["taskNo"]}>
                <TableCell className="font-medium text-blue-600">
                  {task.taskNo}
                </TableCell>
                <TableCell>{task.machineName}</TableCell>
                <TableCell>{task.serialNo}</TableCell>
                <TableCell>{task.doerName}</TableCell>
                <TableCell>{task.department}</TableCell>
                <TableCell>{task.machinePartName}</TableCell>
                <TableCell>
                  <span
                    className={`px-2 py-1 text-xs font-medium rounded-full ${getPriorityColor(
                      task.priority
                    )}`}
                  >
                    {task.priority}
                  </span>
                </TableCell>
                <TableCell>
                  {new Date(task.taskStartDate).toLocaleDateString()}
                </TableCell>
                <TableCell>
                  {new Date(task.taskEndDate).toLocaleDateString()}
                </TableCell>
                <TableCell>
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800 capitalize">
                    {task.status} completed
                  </span>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table> */}

        <div className="relative overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-white">
                <TableRow>
                  <TableHead>Repair Task Number</TableHead>
                  <TableHead>Machine Name</TableHead>
                  <TableHead>Serial No</TableHead>
                  <TableHead>Doer</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Machine Part Name</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead>End Date</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
            </Table>
          </div>
          <div className="overflow-x-auto max-h-[calc(100vh-200px)] overflow-y-auto">
            <Table>
              <TableBody>
                {filteredTasks.map((task) => (
                  <TableRow key={task["taskNo"]}>
                    <TableCell className="font-medium text-blue-600">
                      {task.taskNo}
                    </TableCell>
                    <TableCell>{task.machineName}</TableCell>
                    <TableCell>{task.serialNo}</TableCell>
                    <TableCell>{task.doerName}</TableCell>
                    <TableCell>{task.department}</TableCell>
                    <TableCell>{task.machinePartName}</TableCell>
                    <TableCell>
                      <span
                        className={`px-2 py-1 text-xs font-medium rounded-full ${getPriorityColor(
                          task.priority
                        )}`}
                      >
                        {task.priority}
                      </span>
                    </TableCell>
                    <TableCell>
                      {new Date(task.taskStartDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      {new Date(task.taskEndDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800 capitalize">
                        {task.status} completed
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
        {loadingTasks && (
          <div className="flex flex-col items-center justify-center w-[75vw] mt-10">
            <div className="w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="mt-4 text-gray-600">Loading tasks...</p>
          </div>
        )}
      </div>

      {/* <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Add New Indent"
        size="xl"
      >
        <IndentForm
          onSubmit={handleAddIndent}
          onCancel={() => setIsModalOpen(false)}
          taskList={tasks}
        />
      </Modal> */}
    </div>
  );
};

export default Indent;
